from django import forms

from . import models

class PhonebookForm(forms.ModelForm):
    phones = forms.CharField(widget=forms.Textarea(), help_text = 'separated by new line')

    class Meta:
        model = models.Phonebook
        fields = ('name', 'phones')