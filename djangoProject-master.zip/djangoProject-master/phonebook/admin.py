from django.contrib import admin
from . models import Phonebook, Phone

admin.site.register(Phonebook)
admin.site.register(Phone)
# Register your models here.
