from django.db import models

class Phonebook(models.Model):
    name = models.CharField("names", max_length=50)

    def __str__(self):
        return self.name

class Phone(models.Model):
    phone=models.CharField("phone", max_length=12)
    contact = models.ForeignKey(Phonebook, on_delete=models.CASCADE,
                                related_name="phones")
    def __str__(self):
        return self.phone
