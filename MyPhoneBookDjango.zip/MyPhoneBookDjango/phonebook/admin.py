from django.contrib import admin

from . models import Person, Phone

admin.site.register(Person)
admin.site.register(Phone)

# Register your models here.
